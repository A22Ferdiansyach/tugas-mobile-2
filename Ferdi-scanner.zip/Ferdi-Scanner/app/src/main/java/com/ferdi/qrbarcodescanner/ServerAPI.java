package com.ferdi.qrbarcodescanner;

public class ServerAPI {
    public static String DATA_API = "http://192.168.11.92/";
    public static String URL = "http://192.168.11.92/qrcode/qr/";
}
