# ScanQrCode ✨

![image](https://user-images.githubusercontent.com/79959818/172974274-1348b189-a67e-4b0a-9603-f7d38fdc262e.png)


![image](https://user-images.githubusercontent.com/79959818/171772544-02d7f986-5902-460c-9c59-df504b2cf9b8.png)

